package com.example.sistema_medeiros.ui.cliente;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.sistema_medeiros.R;
import com.example.sistema_medeiros.adapter.ClienteAdapter;
import com.example.sistema_medeiros.model.Cliente;
import com.example.sistema_medeiros.ui.cliente.ClienteViewModel;

import java.util.ArrayList;

public class ClienteFragment extends Fragment {


    private ClienteViewModel clienteViewModel;
    private ClienteAdapter clienteAdapter;
    private RecyclerView recicleView;
    private RecyclerView.LayoutManager clienteManager;
    private View clienteItemsView;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        clienteViewModel =
                ViewModelProviders.of(this).get(ClienteViewModel.class);
        View root = inflater.inflate(R.layout.cliente_fragment, container, false);
//        clienteItemsView = inflater.inflate(R.layout.cliente_fragment, container,false);
//        recicleView = clienteItemsView.findViewById(R.id.clienteRecycle);
//
//        clienteManager = new LinearLayoutManager(getContext());
//        recicleView.setLayoutManager(clienteManager);
//        ArrayList<Cliente>clientes = new ArrayList<Cliente>();
//        clientes.add(new Cliente (1,"dsa1","dsa2","dsa3","ds4","dsa5","dsa6","dsa7","dsa8"));
//        clienteAdapter = new ClienteAdapter(clientes);
//        recicleView.setAdapter(clienteAdapter);
//        return super.onCreateView(inflater,container,savedInstanceState);
////        final TextView textView = root.findViewById(R.id.text_cliente);
//        clienteViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
//            @Override
//            public void onChanged(@Nullable String s) {
//                textView.setText(s);
//            }
//        });
        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }
}