package com.example.sistema_medeiros.ui.funcionarios;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.sistema_medeiros.R;
import com.example.sistema_medeiros.ui.funcionarios.FuncionariosViewModel;

public class FuncionariosFragment extends Fragment {

    private FuncionariosViewModel funcionarioViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        funcionarioViewModel =
                ViewModelProviders.of(this).get(FuncionariosViewModel.class);
        View root = inflater.inflate(R.layout.fragment_funcionario, container, false);
//        final TextView textView = root.findViewById(R.id.text_funcionario);
//        funcionarioViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
//            @Override
//            public void onChanged(@Nullable String s) {
//                textView.setText(s);
//            }
//        });
        return root;
    }

}