package com.example.sistema_medeiros.model;

public class Processo {
    private Integer id;
    private String tipoProcesso;
    private String situacao;
    public Processo(){

    }

    public Processo(Integer id, String tipoProcesso, String situacao) {
        this.id = id;
        this.tipoProcesso = tipoProcesso;
        this.situacao = situacao;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTipoProcesso() {
        return tipoProcesso;
    }

    public void setTipoProcesso(String tipoProcesso) {
        this.tipoProcesso = tipoProcesso;
    }

    public String getSituacao() {
        return situacao;
    }

    public void setSituacao(String situacao) {
        this.situacao = situacao;
    }
}
