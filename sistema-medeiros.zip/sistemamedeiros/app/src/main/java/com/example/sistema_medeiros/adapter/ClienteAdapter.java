package com.example.sistema_medeiros.adapter;


import com.example.sistema_medeiros.R;
import com.example.sistema_medeiros.model.Cliente;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;


import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ClienteAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private ArrayList<Cliente> clientes;

    public ClienteAdapter(ArrayList<Cliente> clientes) {
        this.clientes = clientes;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.list_clientes,parent,false);
        ClienteViewHolder viewHolder = new ClienteViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        Cliente cliente = clientes.get(position);

        ClienteViewHolder clienteViewHolder = (ClienteViewHolder) holder;

        TextView nameTextView = clienteViewHolder.itemView.findViewById(R.id.textNome);
        TextView cpfTextView = clienteViewHolder.itemView.findViewById(R.id.textCpf);
        nameTextView.setText("teste");
        cpfTextView.setText("sdadsa");
    }

    @Override
    public int getItemCount() {
        return clientes.size();
    }
    class ClienteViewHolder extends RecyclerView.ViewHolder{

        public ClienteViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}