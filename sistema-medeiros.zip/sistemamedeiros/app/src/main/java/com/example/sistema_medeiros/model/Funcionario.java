package com.example.sistema_medeiros.model;

public class Funcionario {
}
